#include <REGX52.H>

sbit Buzzer=P1^5;

#define SPEED	1000

#define P	0
#define L1	1
#define L1_	2
#define L2	3
#define L2_	4
#define L3	5
#define L4	6
#define L4_	7
#define L5	8
#define L5_	9
#define L6	10
#define L6_	11
#define L7	12
#define M1	13
#define M1_	14
#define M2	15
#define M2_	16
#define M3	17
#define M4	18
#define M4_	19
#define M5	20
#define M5_	21
#define M6	22
#define M6_	23
#define M7	24
#define H1	25
#define H1_	26
#define H2	27
#define H2_	28
#define H3	29
#define H4	30
#define H4_	31
#define H5	32
#define H5_	33
#define H6	34
#define H6_	35
#define H7	36

unsigned int code FreqTable[]={
	0,
	63628,63731,63835,63928,64021,64103,64185,64260,64331,64400,64463,64528,
	64580,64633,64684,64732,64777,64820,64860,64898,64934,64968,65000,65030,
	65058,65085,65110,65134,65157,65178,65198,65217,65235,65252,65268,65283,
};

unsigned char code Music1[]={
	//??,??,
	//1
	L5,2,
	L5,2,
	L5,2,
	L6,2,
	L5,2,
	M1,2,
	M1,2,
	L4,2,
	//2
	L4,2,
	L4,2,
	L4,2,
	L4,2,
	L4,2,
	L4,2,
	L1,1,
	L2,1,
	L4,2,
	//3
	L5,2,
	L5,2,
	L5,2,
	L6,2,
	L5,2,
	M1,2,
	M1,2,
	M1,2,
	//4
	M1,2,
	L6_,2,
	L6,2,
	L6_,2,
	L6_,2,
	L6_,2,
	L6_,2,
	L6,2,
	//5
	L5,2,
	L5,2,
	L5,2,
	L6,2,
	L5,2,
	M1,2,
	M1,2,
	L4,2,
	//6
	L4,2,
	L4,2,
	L4,2,
	L4,2,
	L4,2,
	L4,2,
	L1,1,
	L2,1,
	L4,2,
	//7
	L5,2,
	L5,2,
	L5,2,
	L6,2,
	L5,2,
	M1,2,
	M1,2,
	M1,2,
	//8
	M1,2,
	L6_,2,
	L6,2,
	L6_,2,
	L6_,4+4,
	//9
	P,4,
	P,2,
	L6_,2,
	L6_,2,
	L6,2,
	L5,2,
	L4,2,
	//10
	L5,2,
	L6,2,
	L6,4+4,
	P,4,
	//11
	P,4,
	P,2,
	L6_,2,
	L6_,2,
	L6,2,
	L5,2,
	L4,2,
	//12
	L5,2,
	L4,2,
	L4,4,
	P,2,
	L4,2,
	L6,2,
	M1,2,
	//13
	M1,4,
	L4,4,
	M2,2,
	M1,2,
	M1,2,
	L6,2,
	//14
	M1,4,
	L4,4,
	M2,2,
	M1,2,
	M1,2,
	L6,2,
	//15
	L6,2,
	L5,2,
	L5,4,
	M2,2,
	M1,2,
	M1,2,
	L6,2,
	//16
	L6,2+1,
	L5,1,
	L5,4+4,
	P,4,
	0xFF
};

unsigned char code Music2[]={
	//17
	P,4,
	P,2,
	L6_,2,
	L6_,2,
	L6,2,
	L5,2,
	L4,2,
	//18
	L5,2,
	L6,2,
	L6,4+4,
	P,4,
	//19
	P,4,
	P,2,
	L6_,2,
	L6_,2,
	L6,2,
	L5,2,
	L4,2,
	//20
	L5,2+1,
	L4,1,
	L4,4,
	P,2,
	L4,2,
	L6,2,
	M3,2,
	//21
	M3,2,
	M4,4,
	M4,2,
	M4,2,
	M5,2,
	M4,2,
	M3,2,
	//22
	M3,2,
	M4,4,
	M4,2,
	M4,2,
	M5,2,
	M4,2,
	M5,2,
	//23
	M6,2,
	M5,4,
	M4,2,
	M4,2,
	M5,2,
	M4,2,
	M5,2,
	//24
	M6,2,
	M6_,2,
	M6,2,
	M5,2,
	M5,2,
	M1,2,
	M1,2,
	M5,2,
	//25
	M5,2,
	M4,2,
	M4,2,
	M6,2,
	M6,2,
	M5,2,
	M3,2,
	M2,2,
	//26
	M2,2,
	M1,2,
	M4,4,
	P,2,
	M1,2,
	M1,2,
	M4,2,
	//27
	M4,2,
	L6_,4,
	M4,2,
	M4,2,
	M3,2,
	M4,2,
	M5,2,
	//28
	M5,2,
	M6,1,
	M6,1,
	M6,4,
	P,2,
	M1,2,
	M1,2,
	M5,2,
	//29
	M5,2,
	M4,2,
	M4,2,
	M6,2,
	M6,2,
	M5,2,
	M4,2,
	M3,2,
	//30
	M2,2,
	M1,2,
	M1,2,
	L6,1,
	M5,1,
	M5,1,
	M4,2+1,
	P,2,
	M1,2,
	//31
	M1,2,
	M2,1,
	L4,1,
	L4,2+1,
	L4,1,
	L6_,2,
	L6,2,
	L5,2+1,
	L4,1,
	//32
	L4,4+4+4,
	P,4,
	0xFE
};

unsigned char FreqSelect,MusicSelect;
signed char ge,shi,bai,Keynum,Scan_bit; 
unsigned char code NixieTable[]={0x3F,0x06,0x5B,0x4F,0x66,0x6D,0x7D,0x07,0x7F,0x6F,0x52};
unsigned char code Poscode[]={0xFE,0xFD,0xFB,0xF7,0xEF,0xDF,0xBF,0x7F};
unsigned char display_buf[8];

void Music_Play(void);
void Timer01Init(void);
void Show_Init(void);
void Delay(unsigned int xms);
void Nixie_set(unsigned char Location,unsigned char Number);

void main()//������������������ֲ���
{
	Timer01Init();
	Show_Init();
	
	while(1)
	{
		if(P3_1 == 0)
		{
			Delay(20);
			while(P3_1 == 0);
			Delay(20);
			Keynum = 1;
		}	
		if(Keynum)
		{
			Music_Play();		
		}
	}
}

void Timer0_Routine() interrupt 1  //����Ƶ
{
	if(FreqTable[FreqSelect])	
	{
		TL0 = FreqTable[FreqSelect]%256;		
		TH0 = FreqTable[FreqSelect]/256;		
		Buzzer=!Buzzer;	
	}
}

void Timer1_Routine() interrupt 3  //����ʱ���������ʾ
{
	static unsigned int T1count = 0;
	
	TL1 = 0x18;		
	TH1 = 0xFC;
	
	if(Keynum)
	{
		T1count++;
		P0 = 0x00;
		P2 = 0xFF;
		P0 = NixieTable[display_buf[Scan_bit]];
		P2 = Poscode[Scan_bit];
		
		Scan_bit++;
		if(Scan_bit >= 8) Scan_bit = 0;
		
		if(T1count >= 1000)
		{
			T1count = 0;
			ge++;
			if(ge > 9)
			{
				ge = 0;
				shi++;
			}
			if(shi > 9)
			{
				shi = 0;
				bai++;
			}
			if(bai >= 1 && shi >= 5 && ge >= 0)
			{
				bai = 0;
				shi = 0;
				ge = 0;
				ET1 = 0;
				TR1 = 0;
			}
			Nixie_set(1,bai);
			Nixie_set(2,shi);
			Nixie_set(3,ge);			
		}
	}
}

void Music_Play()  //���ֲ���
{
	while(1)
	{
		if(Music1[MusicSelect]!=0xFF)	
		{
			FreqSelect=Music1[MusicSelect];	
			MusicSelect++;
			Delay(SPEED/4*Music1[MusicSelect]);	
			MusicSelect++;
			TR0=0;
			Delay(5);
			TR0=1;
		}
		else	
		{
			MusicSelect=0;
			while(1)
			{
				if(Music2[MusicSelect]!=0xFE)				
				{
					FreqSelect=Music2[MusicSelect];	
					MusicSelect++;
					Delay(SPEED/4*Music2[MusicSelect]);
					MusicSelect++;
					TR0=0;
					Delay(5);
					TR0=1;
				}
				else	
				{
					TR0=0;
					while(1);			
				}
			}
		}
	}
}

void Timer01Init()  //��ʱ��0��1�ĳ�ʼ��
{
	TMOD &= 0xF0;		
	TMOD |= 0x01;		
	TL0 = 0x18;		
	TH0 = 0xFC;		
	TF0 = 0;		
	TR0 = 1;		
	
	TMOD &= 0x0F;		
	TMOD |= 0x10;		
	TL1 = 0x18;		
	TH1 = 0xFC;		
	TF1 = 0;		
	TR1 = 1;		
	
	ET0=1;
	ET1=1;
	EA=1;
	PT0=1;
}

void Delay(unsigned int xms)  //��ʱ����
{
	unsigned char i, j;
	while(xms--)
	{
		i = 2;
		j = 239;
		do
		{
			while (--j);
		} while (--i);
	}
}
void Nixie_set(unsigned char Location,unsigned char Number)
{
	if(Location >= 1 && Location <= 8)
	{
		display_buf[Location - 1] = Number;
	}
}
void Show_Init()
{
	Nixie_set(1,bai);
	Nixie_set(2,shi);
	Nixie_set(3,ge);
	Nixie_set(4,10);
	Nixie_set(5,10);
	Nixie_set(6,1);
	Nixie_set(7,5);
	Nixie_set(8,0);
}