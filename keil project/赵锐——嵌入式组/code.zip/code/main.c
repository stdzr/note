#include <REGX52.H>

#define uchar unsigned char
#define uint unsigned int
#define MOVE_SPEED 128
#define TURN_SPEED 10
	
#define  newgame  1 
#define  record  2
#define  setting  3

sbit BEEP =P1^5;

sbit cs1 = P2^0;
sbit cs2 = P2^1;
sbit rs = P2^2;
sbit rw = P2^3;
sbit en = P2^4;

sbit UP = P3^1;
sbit DOWN = P3^3;
sbit LEFT = P3^4;
sbit RIGHT = P3^0;
sbit CLICK = P3^2;

void Delay(uchar xms);
void Timer0Init(void);
void draw_line(uchar x0, uchar y0, uchar x1, uchar y1);
void draw_dot(uchar x, uchar y);
int cast_ray(int startX, int startY, int angle);
void render_3d_view(void);
void move_forward(void);
void move_backward(void);
void turn_left(void);
void turn_right(void);
void busy_12864();
void write_com(uchar com);
void write_dat(uchar dat);
void qp_lcd(void);
void init_12864(void);
void disp8(uchar ye,uchar lie,uchar dat);
void draw_vline(uchar x, uchar y_start, uchar y_len);
void Game_board(void);
void Stop_board(void);
void Record_board(void);
void Setting_board(void);
void Begin_board(void);

uchar select = 0;
uchar score = 0;
uchar Allowmusicplay = 1;
uchar Allowrecord = 0;
uchar END = 0;

uchar Record[4] = {0};
uchar code rhythm[16] = {
2, 1, 1, 1,
2, 1, 1, 3,
2, 1, 2, 1,
2, 1, 1, 0
};

uchar code ch1[]={
0x08,0xF8,0xF8,0x00,0xF8,0xF8,0x08,0x00,0x20,0x3F,0x01,0x3E,0x01,0x3F,0x20,0x00,/*"M",0*/

0x00,0x00,0xC0,0x38,0xE0,0x00,0x00,0x00,0x20,0x3C,0x23,0x02,0x02,0x27,0x38,0x20,/*"A",1*/

0x10,0x08,0x08,0x08,0xC8,0x38,0x08,0x00,0x20,0x38,0x26,0x21,0x20,0x20,0x18,0x00,/*"Z",2*/

0x08,0xF8,0x88,0x88,0xE8,0x08,0x10,0x00,0x20,0x3F,0x20,0x20,0x23,0x20,0x18,0x00,/*"E",3*/

0x00,0x08,0x08,0xF8,0x08,0x08,0x00,0x00,0x00,0x20,0x20,0x3F,0x20,0x20,0x00,0x00,/*"I",4*/
	
0x08,0xF8,0x30,0xC0,0x00,0x08,0xF8,0x08,0x20,0x3F,0x20,0x00,0x07,0x18,0x3F,0x00,/*"N",5*/

0x08,0xF8,0x88,0x88,0xE8,0x08,0x10,0x00,0x20,0x3F,0x20,0x20,0x23,0x20,0x18,0x00,/*"E",6*/

0x08,0xF8,0x00,0xF8,0x00,0xF8,0x08,0x00,0x00,0x03,0x3E,0x01,0x3E,0x03,0x00,0x00,/*"W",7*/

0xC0,0x30,0x08,0x08,0x08,0x38,0x00,0x00,0x07,0x18,0x20,0x20,0x22,0x1E,0x02,0x00,/*"G",8*/

0x00,0x00,0xC0,0x38,0xE0,0x00,0x00,0x00,0x20,0x3C,0x23,0x02,0x02,0x27,0x38,0x20,/*"A",9*/

0x08,0xF8,0xF8,0x00,0xF8,0xF8,0x08,0x00,0x20,0x3F,0x01,0x3E,0x01,0x3F,0x20,0x00,/*"M",10*/

0x08,0xF8,0x88,0x88,0xE8,0x08,0x10,0x00,0x20,0x3F,0x20,0x20,0x23,0x20,0x18,0x00,/*"E",11*/

0x08,0xF8,0x88,0x88,0x88,0x88,0x70,0x00,0x20,0x3F,0x20,0x00,0x03,0x0C,0x30,0x20,/*"R",12*/

0x08,0xF8,0x88,0x88,0xE8,0x08,0x10,0x00,0x20,0x3F,0x20,0x20,0x23,0x20,0x18,0x00,/*"E",13*/

0xC0,0x30,0x08,0x08,0x08,0x08,0x38,0x00,0x07,0x18,0x20,0x20,0x20,0x10,0x08,0x00,/*"C",14*/

0xE0,0x10,0x08,0x08,0x08,0x10,0xE0,0x00,0x0F,0x10,0x20,0x20,0x20,0x10,0x0F,0x00,/*"O",15*/

0x08,0xF8,0x88,0x88,0x88,0x88,0x70,0x00,0x20,0x3F,0x20,0x00,0x03,0x0C,0x30,0x20,/*"R",16*/

0x08,0xF8,0x08,0x08,0x08,0x10,0xE0,0x00,0x20,0x3F,0x20,0x20,0x20,0x10,0x0F,0x00,/*"D",17*/

0x00,0x70,0x88,0x08,0x08,0x08,0x38,0x00,0x00,0x38,0x20,0x21,0x21,0x22,0x1C,0x00,/*"S",18*/

0x08,0xF8,0x88,0x88,0xE8,0x08,0x10,0x00,0x20,0x3F,0x20,0x20,0x23,0x20,0x18,0x00,/*"E",19*/

0x18,0x08,0x08,0xF8,0x08,0x08,0x18,0x00,0x00,0x00,0x20,0x3F,0x20,0x00,0x00,0x00,/*"T",20*/

0x18,0x08,0x08,0xF8,0x08,0x08,0x18,0x00,0x00,0x00,0x20,0x3F,0x20,0x00,0x00,0x00,/*"T",21*/

0x00,0x08,0x08,0xF8,0x08,0x08,0x00,0x00,0x00,0x20,0x20,0x3F,0x20,0x20,0x00,0x00,/*"I",22*/

0x08,0xF8,0x30,0xC0,0x00,0x08,0xF8,0x08,0x20,0x3F,0x20,0x00,0x07,0x18,0x3F,0x00,/*"N",23*/

0xC0,0x30,0x08,0x08,0x08,0x38,0x00,0x00,0x07,0x18,0x20,0x20,0x22,0x1E,0x02,0x00,/*"G",24*/

0x00,0xFC,0xF0,0xE0,0xC0,0x80,0x00,0x00,0x00,0x3F,0x1F,0x0F,0x07,0x03,0x01,0x00,/*">",25*/

0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,/*" ",26*/

0x08,0xF8,0x88,0x88,0x88,0x70,0x00,0x00,0x20,0x3F,0x20,0x20,0x20,0x11,0x0E,0x00,/*"B",27*/

0x08,0xF8,0x88,0x88,0xE8,0x08,0x10,0x00,0x20,0x3F,0x20,0x20,0x23,0x20,0x18,0x00,/*"E",28*/

0x00,0x70,0x88,0x08,0x08,0x08,0x38,0x00,0x00,0x38,0x20,0x21,0x21,0x22,0x1C,0x00,/*"S",29*/

0x18,0x08,0x08,0xF8,0x08,0x08,0x18,0x00,0x00,0x00,0x20,0x3F,0x20,0x00,0x00,0x00,/*"T",30*/

0x00,0x00,0x00,0xC0,0xC0,0x00,0x00,0x00,0x00,0x00,0x00,0x30,0x30,0x00,0x00,0x00,/*":",31*/

0x80,0x80,0x80,0x00,0x80,0x80,0x80,0x00,0x20,0x20,0x3F,0x21,0x20,0x00,0x01,0x00,/*"r",32*/

0x00,0x00,0x80,0x80,0x80,0x80,0x00,0x00,0x00,0x1F,0x24,0x24,0x24,0x24,0x17,0x00,/*"e",33*/

0x00,0x00,0x00,0x80,0x80,0x80,0x00,0x00,0x00,0x0E,0x11,0x20,0x20,0x20,0x11,0x00,/*"c",34*/

0x00,0x00,0x80,0x80,0x80,0x80,0x00,0x00,0x00,0x1F,0x24,0x24,0x24,0x24,0x17,0x00,/*"e",35*/

0x80,0x80,0x00,0x80,0x80,0x80,0x00,0x00,0x20,0x3F,0x21,0x00,0x00,0x20,0x3F,0x20,/*"n",36*/

0x00,0x80,0x80,0xE0,0x80,0x80,0x00,0x00,0x00,0x00,0x00,0x1F,0x20,0x20,0x10,0x00,/*"t",37*/

0x00,0x00,0x10,0x10,0xF8,0x00,0x00,0x00,0x00,0x00,0x20,0x20,0x3F,0x20,0x20,0x00,/*"1",38*/

0x00,0x70,0x08,0x08,0x08,0x08,0xF0,0x00,0x00,0x30,0x28,0x24,0x22,0x21,0x30,0x00,/*"2",39*/

0x00,0x30,0x08,0x08,0x08,0x88,0x70,0x00,0x00,0x18,0x20,0x21,0x21,0x22,0x1C,0x00,/*"3",40*/

0x08,0x78,0x88,0x00,0x00,0xC8,0x38,0x08,0x00,0x00,0x07,0x38,0x0E,0x01,0x00,0x00,/*"V",41*/

0x00,0x08,0x08,0xF8,0x08,0x08,0x00,0x00,0x00,0x20,0x20,0x3F,0x20,0x20,0x00,0x00,/*"I",42*/

0xC0,0x30,0x08,0x08,0x08,0x08,0x38,0x00,0x07,0x18,0x20,0x20,0x20,0x10,0x08,0x00,/*"C",43*/

0x18,0x08,0x08,0xF8,0x08,0x08,0x18,0x00,0x00,0x00,0x20,0x3F,0x20,0x00,0x00,0x00,/*"T",44*/

0xE0,0x10,0x08,0x08,0x08,0x10,0xE0,0x00,0x0F,0x10,0x20,0x20,0x20,0x10,0x0F,0x00,/*"O",45*/

0x08,0xF8,0x88,0x88,0x88,0x88,0x70,0x00,0x20,0x3F,0x20,0x00,0x03,0x0C,0x30,0x20,/*"R",46*/

0x08,0x38,0xC8,0x00,0xC8,0x38,0x08,0x00,0x00,0x00,0x20,0x3F,0x20,0x00,0x00,0x00,/*"Y",47*/

0x08,0xF8,0x08,0x08,0x08,0x10,0xE0,0x00,0x20,0x3F,0x20,0x20,0x20,0x10,0x0F,0x00,/*"D",48*/

0x08,0xF8,0x88,0x88,0xE8,0x08,0x10,0x00,0x20,0x3F,0x20,0x20,0x23,0x20,0x18,0x00,/*"E",49*/

0x08,0xF8,0x88,0x88,0xE8,0x08,0x10,0x00,0x20,0x3F,0x20,0x00,0x03,0x00,0x00,0x00,/*"F",50*/

0x08,0xF8,0x88,0x88,0xE8,0x08,0x10,0x00,0x20,0x3F,0x20,0x20,0x23,0x20,0x18,0x00,/*"E",51*/

0x00,0x00,0xC0,0x38,0xE0,0x00,0x00,0x00,0x20,0x3C,0x23,0x02,0x02,0x27,0x38,0x20,/*"A",52*/

0x18,0x08,0x08,0xF8,0x08,0x08,0x18,0x00,0x00,0x00,0x20,0x3F,0x20,0x00,0x00,0x00,/*"T",53*/

0x08,0xF8,0xF8,0x00,0xF8,0xF8,0x08,0x00,0x20,0x3F,0x01,0x3E,0x01,0x3F,0x20,0x00,/*"M",54*/

0x08,0xF8,0x08,0x00,0x00,0x08,0xF8,0x08,0x00,0x1F,0x20,0x20,0x20,0x20,0x1F,0x00,/*"U",55*/

0x00,0x70,0x88,0x08,0x08,0x08,0x38,0x00,0x00,0x38,0x20,0x21,0x21,0x22,0x1C,0x00,/*"S",56*/

0x00,0x08,0x08,0xF8,0x08,0x08,0x00,0x00,0x00,0x20,0x20,0x3F,0x20,0x20,0x00,0x00,/*"I",57*/

0xC0,0x30,0x08,0x08,0x08,0x08,0x38,0x00,0x07,0x18,0x20,0x20,0x20,0x10,0x08,0x00,/*"C",58*/

0x08,0xF8,0x08,0x08,0x08,0x08,0xF0,0x00,0x20,0x3F,0x21,0x01,0x01,0x01,0x00,0x00,/*"P",59*/

0x08,0xF8,0x08,0x00,0x00,0x00,0x00,0x00,0x20,0x3F,0x20,0x20,0x20,0x20,0x30,0x00,/*"L",60*/

0x00,0x00,0xC0,0x38,0xE0,0x00,0x00,0x00,0x20,0x3C,0x23,0x02,0x02,0x27,0x38,0x20,/*"A",61*/

0x08,0x38,0xC8,0x00,0xC8,0x38,0x08,0x00,0x00,0x00,0x20,0x3F,0x20,0x00,0x00,0x00,/*"Y",62*/

0xC0,0x30,0x08,0x08,0x08,0x08,0x38,0x00,0x07,0x18,0x20,0x20,0x20,0x10,0x08,0x00,/*"C",63*/

0x08,0xF8,0x08,0x00,0x00,0x00,0x00,0x00,0x20,0x3F,0x20,0x20,0x20,0x20,0x30,0x00,/*"L",64*/

0xE0,0x10,0x08,0x08,0x08,0x10,0xE0,0x00,0x0F,0x10,0x20,0x20,0x20,0x10,0x0F,0x00,/*"O",65*/

0x00,0x70,0x88,0x08,0x08,0x08,0x38,0x00,0x00,0x38,0x20,0x21,0x21,0x22,0x1C,0x00,/*"S",66*/

0x08,0xF8,0x88,0x88,0xE8,0x08,0x10,0x00,0x20,0x3F,0x20,0x20,0x23,0x20,0x18,0x00,/*"E",67*/

0xE0,0x10,0x08,0x08,0x08,0x10,0xE0,0x00,0x0F,0x10,0x20,0x20,0x20,0x10,0x0F,0x00,/*"O",68*/

0x08,0xF8,0x08,0x08,0x08,0x08,0xF0,0x00,0x20,0x3F,0x21,0x01,0x01,0x01,0x00,0x00,/*"P",69*/

0x08,0xF8,0x88,0x88,0xE8,0x08,0x10,0x00,0x20,0x3F,0x20,0x20,0x23,0x20,0x18,0x00,/*"E",70*/

0x08,0xF8,0x30,0xC0,0x00,0x08,0xF8,0x08,0x20,0x3F,0x20,0x00,0x07,0x18,0x3F,0x00,/*"N",71*/

0x08,0xF8,0xF8,0x00,0xF8,0xF8,0x08,0x00,0x20,0x3F,0x01,0x3E,0x01,0x3F,0x20,0x00,/*"M",72*/

0xE0,0x10,0x08,0x08,0x08,0x10,0xE0,0x00,0x0F,0x10,0x20,0x20,0x20,0x10,0x0F,0x00,/*"O",73*/

0x08,0xF8,0x08,0x08,0x08,0x10,0xE0,0x00,0x20,0x3F,0x20,0x20,0x20,0x10,0x0F,0x00,/*"D",74*/

0x08,0xF8,0x88,0x88,0xE8,0x08,0x10,0x00,0x20,0x3F,0x20,0x20,0x23,0x20,0x18,0x00,/*"E",75*/

0x00,0x70,0x88,0x08,0x08,0x08,0x38,0x00,0x00,0x38,0x20,0x21,0x21,0x22,0x1C,0x00,/*"S",76*/

0x08,0xF8,0x88,0x88,0xE8,0x08,0x10,0x00,0x20,0x3F,0x20,0x20,0x23,0x20,0x18,0x00,/*"E",77*/

0x08,0xF8,0x08,0x00,0x00,0x00,0x00,0x00,0x20,0x3F,0x20,0x20,0x20,0x20,0x30,0x00,/*"L",78*/

0x08,0xF8,0x88,0x88,0xE8,0x08,0x10,0x00,0x20,0x3F,0x20,0x20,0x23,0x20,0x18,0x00,/*"E",79*/

0xC0,0x30,0x08,0x08,0x08,0x08,0x38,0x00,0x07,0x18,0x20,0x20,0x20,0x10,0x08,0x00,/*"C",80*/

0x18,0x08,0x08,0xF8,0x08,0x08,0x18,0x00,0x00,0x00,0x20,0x3F,0x20,0x00,0x00,0x00,/*"T",81*/

0x08,0xF8,0x08,0x00,0x00,0x08,0xF8,0x08,0x20,0x3F,0x21,0x01,0x01,0x21,0x3F,0x20,/*"H",82*/
};//8��16��ģ���ݣ�ÿ���ֵ���ģ��16�ֽ�

uchar code ch2[]={
0x00,0xE0,0x10,0x08,0x08,0x10,0xE0,0x00,0x00,0x0F,0x10,0x20,0x20,0x10,0x0F,0x00,/*"0",0*/

0x00,0x00,0x10,0x10,0xF8,0x00,0x00,0x00,0x00,0x00,0x20,0x20,0x3F,0x20,0x20,0x00,/*"1",1*/

0x00,0x70,0x08,0x08,0x08,0x08,0xF0,0x00,0x00,0x30,0x28,0x24,0x22,0x21,0x30,0x00,/*"2",2*/

0x00,0x30,0x08,0x08,0x08,0x88,0x70,0x00,0x00,0x18,0x20,0x21,0x21,0x22,0x1C,0x00,/*"3",3*/

0x00,0x00,0x80,0x40,0x30,0xF8,0x00,0x00,0x00,0x06,0x05,0x24,0x24,0x3F,0x24,0x24,/*"4",4*/

0x00,0xF8,0x88,0x88,0x88,0x08,0x08,0x00,0x00,0x19,0x20,0x20,0x20,0x11,0x0E,0x00,/*"5",5*/

0x00,0xE0,0x10,0x88,0x88,0x90,0x00,0x00,0x00,0x0F,0x11,0x20,0x20,0x20,0x1F,0x00,/*"6",6*/

0x00,0x18,0x08,0x08,0x88,0x68,0x18,0x00,0x00,0x00,0x00,0x3E,0x01,0x00,0x00,0x00,/*"7",7*/

0x00,0x70,0x88,0x08,0x08,0x88,0x70,0x00,0x00,0x1C,0x22,0x21,0x21,0x22,0x1C,0x00,/*"8",8*/

0x00,0xF0,0x08,0x08,0x08,0x10,0xE0,0x00,0x00,0x01,0x12,0x22,0x22,0x11,0x0F,0x00,/*"9",9*/
};

uchar code maze[16][16] = {
    {1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1},
    {1,0,0,0,0,0,1,0,0,0,0,0,0,0,0,1},
    {1,0,1,1,1,0,1,0,1,0,1,1,1,1,0,1},
    {1,0,1,0,1,0,0,0,1,0,0,0,0,1,0,1},
    {1,0,1,0,1,1,1,0,1,1,1,1,0,1,0,1},
    {1,0,0,0,1,0,0,0,0,0,0,1,0,0,0,1},
    {1,0,1,0,1,0,1,1,1,1,0,1,0,1,0,1},
    {1,0,1,0,0,0,1,0,0,0,0,0,0,1,0,1},
    {1,0,1,1,1,1,1,0,1,1,1,1,0,1,0,1},
    {1,0,0,0,0,0,0,0,1,0,0,0,0,1,0,1},
    {1,0,1,1,1,1,1,0,1,0,1,1,1,1,0,1},
    {1,0,1,0,0,0,1,0,0,0,0,0,0,0,0,1},
    {1,0,1,0,1,0,1,1,1,1,1,1,0,1,0,1},
    {1,0,0,0,1,0,0,0,0,0,0,0,0,1,0,1},
    {1,0,1,1,1,1,1,1,1,1,1,1,1,1,0,1},
    {1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1}
};

// ��һ��Ŵ� 256 ��
int playerX = 1 * 256 + 128;   
int playerY = 1 * 256 + 128;
int playerAngle = 0;           // ��ʼ�Ƕ�

void main()
{
	init_12864();
	qp_lcd();
	Timer0Init();
	Begin_board();
	
	while(1);
}

void Timer0_Routine() interrupt 1 {
  static uint ms_count = 0;      
  static uchar beat = 0;         
  static uchar fast_toggle = 0;   
  TH0 = 0xFC;         
  TL0 = 0x18;
    
	if(Allowmusicplay)
	{
    ms_count++;
    
    if(ms_count >= 120) {
        ms_count = 0;
        beat = (beat + 1) % 16;
    }
    
    switch(rhythm[beat]) {
        case 1:  // ??
            BEEP = 1;
            break;
        case 2:  // ???(???)
            fast_toggle++;
            BEEP = (fast_toggle & 0x01);  // ????
            break;
        case 0:  // ??
            BEEP = 0;
            break;
    }
    
    if(rhythm[beat] == 2) {
        if(ms_count % 30 == 0) {
            fast_toggle++;
        }
    }
	}
}

void Delay(uchar xms)
{
	unsigned char i, j;

	while(xms--)
	{
		i = 2;
		j = 239;
		do
		{
			while (--j);
		} while (--i);	
	}
}

void Timer0Init()		
{		
	TMOD &= 0xF0;		
	TMOD |= 0x01;		
	TL0 = 0x18;		
	TH0 = 0xFC;		
	TF0 = 0;		
	TR0 = 1;
	ET0 = 1;
	EA = 1;
	PT0 = 0;
}

void draw_dot(uchar x, uchar y)
{
  draw_vline(x, y, 1);
}

void draw_line(uchar x0, uchar y0, uchar x1, uchar y1) {
    int dx, dy, sx, sy, err, e2;
    
    dx = (x1 > x0) ? x1 - x0 : x0 - x1;
    dy = (y1 > y0) ? y1 - y0 : y0 - y1;
    
    sx = (x0 < x1) ? 1 : -1;
    sy = (y0 < y1) ? 1 : -1;
    
    err = dx - dy;
    
    while(1) {
        draw_dot(x0, y0);
        if(x0 == x1 && y0 == y1) break;
        e2 = err * 2;
        if(e2 > -dy) { err -= dy; x0 += sx; }
        if(e2 < dx)  { err += dx; y0 += sy; }
    }
}

uchar is_wall(int gridX, int gridY) {
    if(gridX < 0 || gridX >= 16 || gridY < 0 || gridY >= 16)
        return 1;  // ??????
    return maze[gridY][gridX];
}

int cast_ray(int startX, int startY, int angle) {
    int gridX = startX >> 8;
    int gridY = startY >> 8;
    int stepX = 0, stepY = 0;
    int dist = 128; // ????
    int i;
    
    if(maze[gridY][gridX] == 1) return 256;
    
    // === 16 ????,????? ===
    if(angle >= 349 || angle < 11)            { stepX = 1;  stepY = 0;  } // 0�
    else if(angle >= 11 && angle < 34)        { stepX = 2;  stepY = -1; } // 22.5�
    else if(angle >= 34 && angle < 56)        { stepX = 1;  stepY = -1; } // 45�
    else if(angle >= 56 && angle < 79)        { stepX = 1;  stepY = -2; } // 67.5�
    else if(angle >= 79 && angle < 101)       { stepX = 0;  stepY = -1; } // 90�
    else if(angle >= 101 && angle < 124)      { stepX = -1; stepY = -2; } // 112.5�
    else if(angle >= 124 && angle < 146)      { stepX = -1; stepY = -1; } // 135�
    else if(angle >= 146 && angle < 169)      { stepX = -2; stepY = -1; } // 157.5�
    else if(angle >= 169 && angle < 191)      { stepX = -1; stepY = 0;  } // 180�
    else if(angle >= 191 && angle < 214)      { stepX = -2; stepY = 1;  } // 202.5�
    else if(angle >= 214 && angle < 236)      { stepX = -1; stepY = 1;  } // 225�
    else if(angle >= 236 && angle < 259)      { stepX = -1; stepY = 2;  } // 247.5�
    else if(angle >= 259 && angle < 281)      { stepX = 0;  stepY = 1;  } // 270�
    else if(angle >= 281 && angle < 304)      { stepX = 1;  stepY = 2;  } // 292.5�
    else if(angle >= 304 && angle < 326)      { stepX = 1;  stepY = 1;  } // 315�
    else                                      { stepX = 2;  stepY = 1;  } // 337.5�
    
    // ???????? (?? 256 ?)
    if(stepX == 0 || stepY == 0) {
        // ???:?? 256
        for(i = 0; i < 20; i++) {
            gridX += (stepX != 0) ? (stepX > 0 ? 1 : -1) : 0;
            gridY += (stepY != 0) ? (stepY > 0 ? 1 : -1) : 0;
            
            if(gridX < 0 || gridX >= 16 || gridY < 0 || gridY >= 16) { dist += 256; break; }
            if(maze[gridY][gridX] == 1) { dist += 256; break; }
            dist += 256;
        }
    } 
		else 
		{
      int dx = (stepX > 0) ? 1 : -1;
      int dy = (stepY > 0) ? 1 : -1;
      for(i = 0; i < 20; i++) 
			{
        gridX += dx;
        gridY += dy;
            
        if(gridX < 0 || gridX >= 16 || gridY < 0 || gridY >= 16) { dist += 362; break; }
        if(maze[gridY][gridX] == 1) { dist += 362; break; }
        dist += 362;
      }
    }
    
    return dist;
}

void busy_12864()//LCD12864æ���
{
	P0=0x00;
	rs=0;
	rw=1;
	en=1;
	while(P0&0x80);
	en=0;
}

void write_com(uchar com)//дָ��
{
	busy_12864();
	rs=0;
	rw=0;
	P0=com;
	en=1;
	en=0;
}

void write_dat(uchar dat)//д����
{
	busy_12864();
	rs=1;
	rw=0;
	P0=dat;
	en=1;
	en=0;
}

void qp_lcd()//����
{
    uchar i, j;
    for(i = 0; i < 8; i++)
    {
        cs1 = 0; cs2 = 1;  // ??
        write_com(0xb8 + i);
        write_com(0x40);
        for(j = 0; j < 64; j++)
        {
            write_dat(0x00);
        }
        
        cs1 = 1; cs2 = 0;  // ??
        write_com(0xb8 + i);
        write_com(0x40);
        for(j = 0; j < 64; j++)
        {
            write_dat(0x00);
        }
    }
    cs1 = 1; cs2 = 1;  // ????
}
void render_3d_view(void) {
  uchar col;
  int rayAngle, distance, wallHeight;
  uchar curHeight, prevHeight;
  uchar minHeight, minTop, minBottom;
    
  uchar topPoints[20];
  uchar bottomPoints[20];
  uchar xPoints[20];
  uchar pointCount = 0;
  uchar i;
    
  qp_lcd();
  prevHeight = -1;
  pointCount = 0;
    
  for(col = 0; col < 128; col++) 
	{
    rayAngle = (playerAngle - 30 + (col * 60 / 127)) % 360;
    if(rayAngle < 0) rayAngle += 360;
        
    distance = cast_ray(playerX, playerY, rayAngle);
        
    curHeight = (64 * 256) / distance;
    if(curHeight > 64) curHeight = 64;
    if(curHeight < 2)  curHeight = 2;
        
    if(col == 0 || col == 127 || (prevHeight != -1 && curHeight != prevHeight))
		{
      if(col == 0 || col == 127)
			{
        wallHeight = curHeight;
        minTop = (64 - wallHeight) / 2;
      } 
			else 
			{
        wallHeight = (curHeight < prevHeight) ? curHeight : prevHeight;
        minTop = (64 - wallHeight) / 2;
      }
      minBottom = minTop + wallHeight - 1;
            
      xPoints[pointCount] = col;
      topPoints[pointCount] = minTop;
      bottomPoints[pointCount] = minBottom;
      pointCount++;
    }
        
    prevHeight = curHeight;
  }
    
  for(i = 0; i < pointCount - 1; i++)
	{
    draw_line(xPoints[i], topPoints[i], xPoints[i+1], topPoints[i+1]);
    draw_line(xPoints[i], bottomPoints[i], xPoints[i+1], bottomPoints[i+1]);
  }
    
  for(i = 0; i < pointCount; i++)
	{
    draw_dot(xPoints[i], topPoints[i]);     
    draw_dot(xPoints[i], bottomPoints[i]); 
  }
    
  cs1 = 1;
  cs2 = 1;
}
void move_forward(void)
{
  int newX, newY;
  int moveX, moveY;
  int angle;
    
  angle = playerAngle;
   
  if(angle >= 349 || angle < 11)           { moveX = MOVE_SPEED; moveY = 0;          } // 0
  else if(angle >= 11 && angle < 34)       { moveX = MOVE_SPEED; moveY = -MOVE_SPEED/2; } // 22.5
  else if(angle >= 34 && angle < 56)       { moveX = MOVE_SPEED; moveY = -MOVE_SPEED;   } // 45
  else if(angle >= 56 && angle < 79)       { moveX = MOVE_SPEED/2; moveY = -MOVE_SPEED; } // 67.5
  else if(angle >= 79 && angle < 101)      { moveX = 0;          moveY = -MOVE_SPEED;   } // 90
  else if(angle >= 101 && angle < 124)     { moveX = -MOVE_SPEED/2; moveY = -MOVE_SPEED; } // 112.5
  else if(angle >= 124 && angle < 146)     { moveX = -MOVE_SPEED; moveY = -MOVE_SPEED;   } // 135
  else if(angle >= 146 && angle < 169)     { moveX = -MOVE_SPEED; moveY = -MOVE_SPEED/2; } // 157.5
  else if(angle >= 169 && angle < 191)     { moveX = -MOVE_SPEED; moveY = 0;          } // 180
  else if(angle >= 191 && angle < 214)     { moveX = -MOVE_SPEED; moveY = MOVE_SPEED/2;  } // 202.5
  else if(angle >= 214 && angle < 236)     { moveX = -MOVE_SPEED; moveY = MOVE_SPEED;    } // 225
  else if(angle >= 236 && angle < 259)     { moveX = -MOVE_SPEED/2; moveY = MOVE_SPEED;  } // 247.5
  else if(angle >= 259 && angle < 281)     { moveX = 0;          moveY = MOVE_SPEED;    } // 270
  else if(angle >= 281 && angle < 304)     { moveX = MOVE_SPEED/2; moveY = MOVE_SPEED;   } // 292.5
  else if(angle >= 304 && angle < 326)     { moveX = MOVE_SPEED; moveY = MOVE_SPEED;    } // 315
  else                                     { moveX = MOVE_SPEED; moveY = MOVE_SPEED/2;  } // 337.5
    
  newX = playerX + moveX;
  newY = playerY + moveY;
    
  if(is_wall(newX >> 8, newY >> 8) == 0)
	{
    playerX = newX;
    playerY = newY;
  }
}

void move_backward(void)
{
  int newX, newY;
  int moveX, moveY;
  int angle;
    
  angle = playerAngle;
    
  if(angle >= 349 || angle < 11)           { moveX = -MOVE_SPEED; moveY = 0;          }
  else if(angle >= 11 && angle < 34)       { moveX = -MOVE_SPEED; moveY = MOVE_SPEED/2;  }
  else if(angle >= 34 && angle < 56)       { moveX = -MOVE_SPEED; moveY = MOVE_SPEED;    }
  else if(angle >= 56 && angle < 79)       { moveX = -MOVE_SPEED/2; moveY = MOVE_SPEED;  }
  else if(angle >= 79 && angle < 101)      { moveX = 0;          moveY = MOVE_SPEED;    }
  else if(angle >= 101 && angle < 124)     { moveX = MOVE_SPEED/2; moveY = MOVE_SPEED;   }
  else if(angle >= 124 && angle < 146)     { moveX = MOVE_SPEED; moveY = MOVE_SPEED;    }
  else if(angle >= 146 && angle < 169)     { moveX = MOVE_SPEED; moveY = MOVE_SPEED/2;  }
  else if(angle >= 169 && angle < 191)     { moveX = MOVE_SPEED; moveY = 0;          }
  else if(angle >= 191 && angle < 214)     { moveX = MOVE_SPEED; moveY = -MOVE_SPEED/2; }
  else if(angle >= 214 && angle < 236)     { moveX = MOVE_SPEED; moveY = -MOVE_SPEED;   }
  else if(angle >= 236 && angle < 259)     { moveX = MOVE_SPEED/2; moveY = -MOVE_SPEED; }
  else if(angle >= 259 && angle < 281)     { moveX = 0;          moveY = -MOVE_SPEED;   }
  else if(angle >= 281 && angle < 304)     { moveX = -MOVE_SPEED/2; moveY = -MOVE_SPEED; }
  else if(angle >= 304 && angle < 326)     { moveX = -MOVE_SPEED; moveY = -MOVE_SPEED;   }
  else                                     { moveX = -MOVE_SPEED; moveY = -MOVE_SPEED/2; }
    
  newX = playerX + moveX;
  newY = playerY + moveY;
    
  if(is_wall(newX >> 8, newY >> 8) == 0) 
	{
    playerX = newX;
    playerY = newY;
  }
}

void turn_left()
{
  playerAngle -= TURN_SPEED;
  if(playerAngle < 0) playerAngle += 360;
}

void turn_right()
{
  playerAngle += TURN_SPEED;
  if(playerAngle >= 360) playerAngle -= 360;
}

void init_12864()//LCD12864��ʼ��
{
	write_com(0x3f);//����ʾ
	write_com(0xc0);//��һ���ַ���ʾ������������
	qp_lcd();//����
}
//8��16������ʾ����������yeΪҳ����lieΪ������datΪ��ģ�������������ڵڼ�������
void disp8(uchar ye,uchar lie,uchar dat)
{
	uchar i;
	if(lie<64)//����С��64ѡ������
	{
		cs1=0;
		cs2=1;
	}
	else//����ѡ����������������64~127֮��仯ʱ����ʹ����ֵ�޶���0~63
	{
		cs1=1;
		cs2=0;
		lie-=64;
	}
	write_com(0xb8+ye);//�����ַ����ڵ�ҳ��ַ
	write_com(0x40+lie);//�����ַ����ڵ��е�ַ������0~127֮��ȡֵ
	for(i=0;i<8;i++)
	{
		write_dat(ch1[i+16*dat]);//д������һҳ
	}
	write_com(0xb8+ye+1);//ҳ��ַ+1
	write_com(0x40+lie);
	for(i=8;i<16;i++)
	{
		write_dat(ch1[i+16*dat]);//д������һҳ
	}	
}

void draw_vline(uchar x, uchar y_start, uchar y_len)
{
    uchar page_start, page_end, i;
    uchar dat;
    
    if(x > 127 || y_start > 63) return;
    if(y_start + y_len > 64) y_len = 64 - y_start;
    if(y_len == 0) return;
    
    page_start = y_start / 8;
    page_end = (y_start + y_len - 1) / 8;
    
    if(x < 64) {
        cs1 = 0; cs2 = 1;
    } else {
        cs1 = 1; cs2 = 0;
        x -= 64;
    }
    
    for(i = page_start; i <= page_end; i++) {
        if(i == page_start && i == page_end) {
            dat = (0xFF << (y_start % 8)) & (0xFF >> (7 - ((y_start + y_len - 1) % 8)));
        } else if(i == page_start) {
            dat = 0xFF << (y_start % 8);
        } else if(i == page_end) {
            dat = 0xFF >> (7 - ((y_start + y_len - 1) % 8));
        } else {
            dat = 0xFF;
        }
        
        write_com(0xB8 | i);
        write_com(0x40 | x);
        write_dat(dat);       
    }
    
    cs1 = 1; cs2 = 1;
}

void Game_board()
{
	uchar exitFlag = 0, keynum3 = 0;
	bit up_old = 1, down_old = 1, left_old = 1, right_old = 1, click_old = 1;
	int gridX, gridY;
	render_3d_view();
	
  while(1)
	{
		gridX = playerX >> 8;
		gridY = playerY >> 8;
		if(gridX == 14 && gridY == 14)
		{
			score = 100;
			Allowrecord = 1;
			qp_lcd();
			disp8(2,40,41);  disp8(2,48,42);  disp8(2,56,43);  disp8(2,64,44);  disp8(2,72,45);  disp8(2,80,46); disp8(2,88,47);
			while(keynum3 == 0)
			{
				if(CLICK == 0 && click_old == 1) 
				{
					Delay(50);
					if(CLICK == 0)
					{
						keynum3 = 1;
					}
				}
				click_old = CLICK;				
			}
			qp_lcd();
			Begin_board();
		}
		
    if(UP == 0 && up_old == 1) 
		{
      Delay(50);
      if(UP == 0)
			{
        move_forward();
        render_3d_view();
      }
    }
    up_old = UP;
        
    if(DOWN == 0 && down_old == 1)
		{
      Delay(50);
      if(DOWN == 0)
			{
        move_backward();
        render_3d_view();            
			}
    }
    down_old = DOWN;
        
    if(LEFT == 0 && left_old == 1) 
		{
      Delay(50);
      if(LEFT == 0)
			{
        turn_left();
        render_3d_view();
      }
    }
    left_old = LEFT;
        
    if(RIGHT == 0 && right_old == 1) 
		{
      Delay(50);
      if(RIGHT == 0) 
			{
				turn_right();
				render_3d_view();            
			}
    }
    right_old = RIGHT;
				
    if(CLICK == 0 && click_old == 1) 
		{
      Delay(50);
      if(CLICK == 0)
			{
        exitFlag = 1;
      }
    }
    click_old = CLICK;

		if(exitFlag == 1)
		{		
			qp_lcd();
			Stop_board();
		}
				
		Delay(10);
  }
}
void Stop_board()
{
  uchar keynum1 = 0;
  uchar last_select = 0;
  bit up_old = 1, down_old = 1, click_old = 1;  // �µİ�������������״̬�Ƚϴ���
    
  Delay(5000);
  select = 1;
		
	disp8(2,48,82);  disp8(2,56,73);  disp8(2,64,72);  disp8(2,72,77);
 	disp8(4,48,80);  disp8(4,56,73);  disp8(4,64,71);  disp8(4,72,81);  disp8(4,80,22);  disp8(4,88,71); disp8(4,96,55); disp8(4,104,77);
    
  disp8(2 * select, 30, 25);
  last_select = select;
    
  while(1)
  {
    if(UP == 0 && up_old == 1)
		{
      Delay(50);
      if(UP == 0)
			{
        select--;
        if(select < 1) select = 2;
      }
    }
    up_old = UP;
        
    if(DOWN == 0 && down_old == 1)
		{
      Delay(50);
      if(DOWN == 0) 
			{
				select++;
				if(select > 2) select = 1;
      }
    }
    down_old = DOWN;
        
    if(CLICK == 0 && click_old == 1) 
		{
      Delay(50);
      if(CLICK == 0) 
			{
        keynum1 = 1;
      }
    }
    click_old = CLICK;
        
    if(select != last_select)
		{
      disp8(2 * last_select, 30, 26);  
      disp8(2 * select, 30, 25);    
      last_select = select;
    }
        
    if(keynum1 == 1) 
		{
      if(select == 1)
			{
			  playerX = 1 * 256 + 128;   
				playerY = 1 * 256 + 128;
				playerAngle = 0;
				qp_lcd();
				Begin_board();
				return;
			}
			if(select == 2)
			{
				Game_board();
			}
		}      
     
		Delay(10);  
  }
}
void Record_board()
{
	uchar keynum2 = 0;
	bit click_old = 1;
	qp_lcd();
	disp8(0,0,27);  disp8(0,8,28);  disp8(0,16,29);  disp8(0,24,30);  disp8(0,32,31);
  disp8(2,0,32);  disp8(2,8,33);  disp8(2,16,34);  disp8(2,24,35);  disp8(2,32,36);  disp8(2,40,37); disp8(2,48,38); disp8(2,56,31);
	disp8(4,0,32);  disp8(4,8,33);  disp8(4,16,34);  disp8(4,24,35);  disp8(4,32,36);  disp8(4,40,37); disp8(4,48,39); disp8(4,56,31);
  disp8(6,0,32);  disp8(6,8,33);  disp8(6,16,34);  disp8(6,24,35);  disp8(6,32,36);  disp8(6,40,37); disp8(6,48,40); disp8(6,56,31);
	
	if(Allowrecord)
	{
		
	}
	
	Delay(5000);
	
	while(1)
	{
		if(CLICK == 0 && click_old == 1) 
		{
			Delay(50);
			if(CLICK == 0)
			{
				keynum2 = 1;
			}
		}
		click_old = CLICK;
	
		if(keynum2 == 1)
		{
			qp_lcd();
			Begin_board();
		}
		
		Delay(10);
	}
}

void Setting_board()
{
	uchar keynum1 = 0, keynum2 = 0;
  uchar last_select = 0;
  bit left_old = 1, right_old = 1, click_old = 1;
	
	Delay(5000);
	select = 1;
	
	qp_lcd();
	disp8(0,0,54); disp8(0,8,55); disp8(0,16,56); disp8(0,24,57); disp8(0,32,58);	disp8(0,48,59); disp8(0,56,60); disp8(0,64,61); disp8(0,72,62);
  disp8(2,16,63); disp8(2,24,64); disp8(2,32,65); disp8(2,40,66); disp8(2,48,67); disp8(2,72,68); disp8(2,80,69); disp8(2,88,70); disp8(2,96,71);
	disp8(4,0,72); disp8(4,8,73); disp8(4,16,74); disp8(4,24,75); disp8(4,40,76); disp8(4,48,77); disp8(4,56,78); disp8(4,64,79); disp8(4,72,80); disp8(4,80,81);
  disp8(6,16,38); disp8(6,72,39);
	
	disp8(2, 4, 25);
  last_select = select;
    
  while(1)
  {
    if(LEFT == 0 && left_old == 1)
		{
      Delay(50);
      if(LEFT == 0)
			{
        select--;
        if(select < 1) select = 2;
      }
    }
    left_old = LEFT;
        
    if(RIGHT == 0 && right_old == 1)
		{
      Delay(50);
      if(RIGHT == 0) 
			{
				select++;
				if(select > 2) select = 1;
      }
    }
    right_old = RIGHT;
        
    if(CLICK == 0 && click_old == 1) 
		{
      Delay(50);
      if(CLICK == 0) 
			{
        keynum1 = 1;
      }
    }
    click_old = CLICK;
        
    if(select != last_select)
		{
			if(select == 1) disp8(2, 4, 25);
			else disp8(2, 56, 25);
			
			if(last_select == 1) disp8(2, 4, 26);
			else disp8(2, 56, 26);
      last_select = select;
    }
     
		if(keynum1 == 1)
		{
			if(select == 1)
			{
				Allowmusicplay = 0;
			}
			if(select == 2)
			{
				Allowmusicplay = 1;
			}
			
			disp8(2, 4, 26); disp8(2, 56, 26);
			select = 1;
			disp8(6, 4, 25);
			last_select = select;
			
			while(1)
			{
				if(LEFT == 0 && left_old == 1)
				{
					Delay(50);
					if(LEFT == 0)
					{
						select--;
						if(select < 1) select = 2;
					}
				}
				left_old = LEFT;
						
				if(RIGHT == 0 && right_old == 1)
				{
					Delay(50);
					if(RIGHT == 0) 
					{
						select++;
						if(select > 2) select = 1;
					}
				}
				right_old = RIGHT;
						
				if(CLICK == 0 && click_old == 1) 
				{
					Delay(50);
					if(CLICK == 0) 
					{
						keynum2 = 1;
					}
				}
				click_old = CLICK;	
				
				if(select != last_select)
				{
					if(select == 1) disp8(6, 4, 25);
					else disp8(6, 56, 25);
					
					if(last_select == 1) disp8(6, 4, 26);
					else disp8(6, 56, 26);
					last_select = select;
				}
		
				if(keynum2 == 1)
				{
					qp_lcd();
					Begin_board();
				}
			}
		}
		Delay(10);  // ѭ����ʱ,���� CPU ����
	}
}

void Begin_board()
{
    uchar keynum1 = 0;
    uchar last_select = 0;
    bit up_old = 1, down_old = 1, click_old = 1;  // �µİ�������������״̬�Ƚϴ���
    
		Delay(5000);
    select = 1;
		
    disp8(0,42,0);  disp8(0,50,1);  disp8(0,58,2);  disp8(0,66,3);  disp8(0,76,4);
    disp8(2,42,5);  disp8(2,50,6);  disp8(2,58,7);  disp8(2,68,8);  disp8(2,76,9);  disp8(2,84,10); disp8(2,92,11);
    disp8(4,42,12); disp8(4,50,13); disp8(4,58,14); disp8(4,66,15); disp8(4,74,16); disp8(4,82,17);
    disp8(6,42,18); disp8(6,50,19); disp8(6,58,20); disp8(6,66,21); disp8(6,74,22); disp8(6,82,23); disp8(6,90,24);
    
    disp8(2 * select, 30, 25);
    last_select = select;
    
  while(1)
  {
    if(UP == 0 && up_old == 1)
		{
      Delay(50);
      if(UP == 0)
			{
        select--;
        if(select < 1) select = 3;
      }
    }
    up_old = UP;
        
    if(DOWN == 0 && down_old == 1)
		{
      Delay(50);
      if(DOWN == 0) 
			{
				select++;
				if(select > 3) select = 1;
      }
    }
    down_old = DOWN;
        
    if(CLICK == 0 && click_old == 1) 
		{
      Delay(50);
      if(CLICK == 0) 
			{
        keynum1 = 1;
      }
    }
    click_old = CLICK;
        
    if(select != last_select)
		{
      disp8(2 * last_select, 30, 26);  
      disp8(2 * select, 30, 25);      
      last_select = select;
    }
        
    if(keynum1 == 1) 
		{
      switch(select)
			{
				case newgame:
					Game_board();
					break;
				case record:
					Record_board();
					break;
				case setting:
					Setting_board();
					break;
				default:
					break;
			}
      break;
		}      
     
		Delay(10);  // ѭ����ʱ,���� CPU ����
  }
}